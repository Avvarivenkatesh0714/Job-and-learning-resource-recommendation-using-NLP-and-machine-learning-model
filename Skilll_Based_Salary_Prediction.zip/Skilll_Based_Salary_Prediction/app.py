import pandas as pd
import pickle
import spacy
from flask import Flask, render_template, request, jsonify
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler
from gensim.models import Word2Vec
from werkzeug.utils import secure_filename
import os
import PyPDF2

# Load NLP model for parsing skills
nlp = spacy.load("en_core_web_sm")

# Load dataset
df = pd.read_csv("jobs.csv")  # Columns: 'job_role', 'location', 'salary', 'required_skills'
df["skills"] = df["required_skills"].apply(lambda x: x.lower().split(", ") if isinstance(x, str) else [])


# Train Word2Vec model
word2vec = Word2Vec(sentences=df["skills"], vector_size=100, min_count=1, window=5, sg=0)
pickle.dump(word2vec, open("word2vec.pkl", "wb"))

# Convert skills to vectors
def get_vector(words):
    vectors = [word2vec.wv[word] for word in words if word in word2vec.wv]
    return sum(vectors) / len(vectors) if vectors else None

df["skill_vectors"] = df["skills"].apply(get_vector)
df = df.dropna(subset=["skill_vectors"])

# Train SVM model
X = list(df["skill_vectors"])
y = df["salary"]

scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

model = SVR(kernel="linear")
model.fit(X_scaled, y)

pickle.dump(model, open("model.pkl", "wb"))

# Flask App
app = Flask(__name__)
UPLOAD_FOLDER = "uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Resume Parsing Function
def extract_skills_from_resume(pdf_path):
    with open(pdf_path, "rb") as pdf_file:
        reader = PyPDF2.PdfReader(pdf_file)
        text = " ".join([page.extract_text() for page in reader.pages if page.extract_text()])
    
    doc = nlp(text)
    skills = [token.text.lower() for token in doc if token.is_alpha]
    return list(set(skills))

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload_resume():
    try:
        file = request.files["resume"]
        if not file or not file.filename.endswith(".pdf"):
            return jsonify({"error": "Only PDF resumes are allowed"}), 400

        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        file.save(filepath)

        extracted_skills = extract_skills_from_resume(filepath)

        # Load trained models
        model = pickle.load(open("model.pkl", "rb"))
        word2vec = pickle.load(open("word2vec.pkl", "rb"))

        # Get skill vector
        skill_vector = get_vector(extracted_skills)
        if skill_vector is None:
            return jsonify({"error": "No relevant skills found in resume"}), 400

        predicted_salary = model.predict(scaler.transform([skill_vector]))[0]

        # Find 4 matching jobs
        df["similarity"] = df["skill_vectors"].apply(lambda x: word2vec.wv.cosine_similarities(skill_vector, [x])[0])
        matched_jobs = df.sort_values(by="similarity", ascending=False).head(7)[["job_role", "location", "salary"]].to_dict(orient="records")

        return jsonify({"predicted_salary": predicted_salary, "matched_jobs": matched_jobs})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
